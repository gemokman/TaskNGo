//
//  ViewController.swift
//  Task N Go
//
//  Created by STDC_45 on 13/05/2024.
//

import UIKit

class LoginViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.setHidesBackButton(true, animated: false)
        
    }


}

