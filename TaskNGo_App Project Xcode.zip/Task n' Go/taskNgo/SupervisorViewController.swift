//
//  ViewController.swift
//  Prototype
//
//  Created by STDC_21 on 15/05/2024.
//

import UIKit

class SupervisorViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

